<?php

$databaseHost = 'localhost';
$databaseName = 'poliwilliambooth';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect(
    $databaseHost,
    $databaseUsername,
    $databasePassword,
    $databaseName
);

?>